package com.user.user_ms.dto;

import lombok.Data;

@Data
public class NotificationDTO {
	  int notificationId;
	  String notificationString;
	  int userId;

}
