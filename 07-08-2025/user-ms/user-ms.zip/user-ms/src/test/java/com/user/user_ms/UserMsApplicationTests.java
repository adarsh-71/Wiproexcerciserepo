package com.user.user_ms;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class UserMsApplicationTests {

	@Test
	void contextLoads() {
	}

}
